# Auditoría SEO · 16 Ball Creations · 23 oct 2026

Sitio: https://16ballcreations.com
Accesos: Search Console sí (propiedad de dominio `sc-domain:16ballcreations.com`) · Bing no · GA4 no
Páginas revisadas: `/` (portada), `/servicios/`, `/servicios/auditoria-de-marca/`, `/servicios/identidad-de-marca/`, `/servicios/paginas-web/`, `/servicios/tiendas-en-linea/`, `/servicios/sistemas-para-tu-negocio/`, `/servicios/asesoria-de-imagen-y-redes/`, `/mira/`, y las 9 versiones en inglés de `/en/` para títulos, canonical y hreflang. El sitio no tiene página de contacto aparte (el contacto es la sección `#contacto` de la portada) ni páginas de contenido. Son 18 URLs, así que no hizo falta un rastreo completo.

Checklist: [checklist-seo-agente.md](checklist-seo-agente.md) v0.3 · Criterios: [guia-seo.md](guia-seo.md) v0.3. La revisión se hizo el 23 oct con la v0.2 y se recalculó con la v0.3 el 20 nov 2026. Auditoría de solo lectura: no se cambió nada del sitio ni de las cuentas. En Search Console solo se consultaron informes y se usó «Probar URL publicada», que no cambia nada. No se pidió indexación.

## Puntuación

**80 / 100 · Por buen camino** (cobertura 99 %) · auditoría anterior: no hay, esta es la primera y queda como línea base.
Tipo de negocio (LOC-00): **sin perfil posible**. 16 Ball Creations trabaja en línea y por videollamada, sin un local que atienda público, y Google pidió una verificación en video que no se puede hacer. Por eso el perfil de empresa en Google (LOC-01) no aplica y no resta.
Insignias: **Ordenado** · **Útil** · **Bien ilustrado** · **Juego limpio**
Te faltan **10 puntos** para «Referente» (90).

> **Recálculo del 23 oct 2026.** La primera versión de esta auditoría daba **59, «Primeros pasos»**, porque el checklist trataba el perfil de Google como crítico para todos los negocios, y eso ponía un tope. Con la regla nueva del checklist (el perfil depende del tipo de negocio), LOC-01 pasa a `N/A`, se evalúa LOC-08 (señales locales sin perfil) e IDX-14 pasa a `PARCIAL` (IndexNow no encontrado). Los datos de la revisión son los mismos.

> **Recálculo con el checklist v0.3 (20 nov 2026): de 79 a 80.** La v0.3 agrega siete puntos (IDX-16, KW-09, CON-11, CON-12, ONP-11, ONP-12 y LNK-07). Se evaluaron sobre el sitio tal como estaba durante esta auditoría: el commit `b28a773` del repositorio `16bc-site`, el último antes de las 11:30 del 23 oct. No se usó el sitio de hoy, que ya cambió (Esencia de marca, Ecosistema digital, estudio y proyectos). Los siete pasan y suman 13 puntos. Las reglas nuevas para los puntos que se revisan página por página no cambian ningún resultado anterior: lo que estaba en `PARCIAL` se cumple a medias en cada página (IA-01, IA-10, SCH-04, ONP-02, ONP-07) o falla en menos de la mitad (IDX-02, ONP-05, ONP-08). Las columnas de esfuerzo y fuente y el inventario de páginas se estrenan en la próxima auditoría.

| Área | Puntuación |
|---|---|
| MED | ██████░░░░ 59 % |
| IDX | ████████░░ 84 % |
| EST | ██████████ 100 % |
| KW | ███████░░░ 65 % |
| CON | ██████████ 100 % |
| ONP | ████████░░ 78 % |
| IMG | ██████████ 100 % |
| LNK | ██████████ 100 % |
| RND | ████████░░ 82 % |
| SCH | ███████░░░ 69 % |
| IA | ████████░░ 79 % |
| LOC | ███░░░░░░░ 29 % |
| AUT | ████░░░░░░ 36 % |

Cuenta: 218,5 puntos ganados de 273 posibles (283 del tipo «sin perfil posible», menos 7 de otros `N/A` y 3 de `SIN ACCESO`).

No hay topes: ningún crítico está en `FALLA` y no hay spam.

Los tres arreglos que más suman:
1. [Importante] KW-01 y KW-03 · +6 · Escribir el mapa de búsquedas: una búsqueda principal por página, con su intención. Es un documento, sin tocar el sitio.
2. [Importante] LOC-04 · +3 (y +1,5 más por ONP-02) · Poner «Medellín» en el `<title>` y el `<h1>` de las páginas de servicio, empezando por `/servicios/paginas-web/`.
3. [Importante] MED-03 · +3 · Instalar analítica con tres conversiones: MIRA, WhatsApp y correo.

Con esos tres, el sitio sube a **85**. El crítico más barato de completar es LOC-02 (+2,5): cambiar el correo de Facebook.

Arreglos rápidos (minutos): LOC-02, el correo de Facebook, e IDX-09, la regla de redirección de `http://www.`.

Insignia más cerca: **Rápido** (solo falta RND-01, el LCP).

## Resumen

- Críticos que fallan: 0. Críticos en `PARCIAL`: 5 (IDX-02, IDX-03, IDX-09, SCH-04, LOC-02)
- Importantes que fallan: 7 (MED-03, KW-01, KW-03, RND-01, LOC-03, LOC-04, AUT-03). Importantes en `PARCIAL`: 12 (incluye LOC-08)
- Mejoras en `PARCIAL`: 6 (incluye IDX-14)
- Sin acceso: 1 (MED-02, Bing Webmaster Tools)
- Spam: ninguno. Search Console dice «No se ha detectado ningún problema» en Acciones manuales y en Problemas de seguridad.

Lo técnico está bien hecho: Google rastrea, indexa y entiende el sitio, y las páginas son propias, claras y bien enlazadas. Lo que falla está fuera del sitio: no hay reseñas ni directorios, el sitio no tiene ningún enlace externo y Facebook cuenta otra versión de la empresa. Cuando alguien busca «diseño de páginas web Medellín», arriba sale un mapa con negocios que tienen perfil de Google. 16 Ball no puede entrar en ese mapa porque no tiene local, así que compite en los resultados de abajo y en las respuestas de IA, donde pesan los directorios, las reseñas y que la ciudad esté escrita en cada página. Dentro del sitio, lo más urgente es que `/servicios/sistemas-para-tu-negocio/` no está indexada, que las páginas de servicio no dicen «Medellín» en el título y que no hay analítica para medir conversiones.

## Resultados

### 1. Medición (MED)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| MED-01 | OK | Propiedad de dominio verificada en Search Console, con datos desde el 13 oct 2026 | — |
| MED-02 | SIN ACCESO | No hubo acceso a Bing Webmaster Tools. El HTML no trae la meta `msvalidate.01`, pero la verificación puede ser por DNS o importada de Search Console | Confirmar si existe. Si no, importarla desde Search Console en bing.com/webmasters (es el punto 4.6 de [mejoras-sitio-seo-aeo.md](../../planes/mejoras-sitio-seo-aeo.md)) |
| MED-03 | FALLA | Ninguna de las 18 páginas ni los 7 archivos JS del sitio cargan analítica (`gtag`, `G-`, GTM, Plausible, Umami, Clarity ni el beacon de Cloudflare) | Instalar GA4, o Cloudflare Web Analytics más eventos, con al menos tres conversiones: envío de la MIRA, clic en WhatsApp y clic en el correo |
| MED-04 | PARCIAL | Hay una prueba de IA con fecha (22 oct, en [mejoras-sitio-seo-aeo.md](../../planes/mejoras-sitio-seo-aeo.md)), pero falta registrar lo demás: indexadas, clics, impresiones y CWV | Usar esta auditoría como línea base. Al 23 oct: 17 páginas indexadas y 7 sin indexar, 2 clics y 7 impresiones (13-21 oct), posición media 10,6, CWV sin datos de campo |

### 2. Rastreo e indexación (IDX)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| IDX-01 | OK | `site:16ballcreations.com` devuelve la portada, `/servicios/`, `/mira/` y las páginas de servicio en español e inglés (2 páginas de resultados) | — |
| IDX-02 | PARCIAL | Inspección de URLs: 8 de las 9 páginas en español están indexadas. **`/servicios/sistemas-para-tu-negocio/` sale como «Rastreada: actualmente sin indexar»**. El informe general dice 17 indexadas y 7 sin indexar (4 redirecciones, 2 alternativas con canonical correcto y 1 rastreada sin indexar), con última actualización el 15 oct | Hacer la página más propia y útil: un caso real, para quién es y precio o rango. Enlazarla desde la portada y desde las otras páginas de servicio, y después pedir la indexación |
| IDX-03 | PARCIAL | En la prueba publicada de la portada (23 oct, 11:10), la captura de Googlebot para smartphones **solo muestra el menú y la animación de las bolas, sin texto**: el titular, el `<h1>` y la sección de proyectos no aparecen. El HTML probado sí trae todo el texto y no hubo recursos bloqueados ni errores de JS. En `/servicios/paginas-web/`, en cambio, la captura muestra el `<h1>`, el subtítulo y los botones | Que el `<h1>` y el texto principal de la portada se vean desde el primer momento, sin esperar a que termine la animación de entrada (mostrar primero y animar después). Ver también RND-01 |
| IDX-04 | OK | `robots.txt` existe, permite `/`, bloquea solo `/admin` y `/api/` y declara el `Sitemap:` | — |
| IDX-05 | OK | `/testimonio/` y `/autorizacion/` no se bloquean en `robots.txt` y llevan `noindex, nofollow` (el mismo `robots.txt` lo explica en un comentario) | — |
| IDX-06 | OK | `noindex` en `/testimonio/` y `/autorizacion/`. El sitio no tiene páginas de gracias, búsqueda ni filtros. Ninguna página importante lleva `noindex` | — |
| IDX-07 | OK | `sitemap.xml` con 18 URLs que responden 200, todas indexables. En Search Console está enviado el 22 oct, en estado «Correcto», con 18 páginas descubiertas. Detalle: se envió con `www` (`https://www.16ballcreations.com/sitemap.xml`), una dirección que redirige | Volver a enviarlo con la dirección sin `www`, la misma de `robots.txt`, y quitar el de `www` |
| IDX-08 | OK | `curl -s` trae el `<h1>` y el texto principal en todas las páginas (por ejemplo, 2.128 palabras en la portada y 957 en páginas web) | — |
| IDX-09 | PARCIAL | `http://16ballcreations.com` y `https://www.16ballcreations.com` hacen un 301 a `https://16ballcreations.com/` en un salto, pero **`http://www.16ballcreations.com` da dos saltos**: un 301 a `https://www.` y otro 301 al dominio sin `www` | Regla de redirección en Cloudflare: `http://www.*` va directo con 301 a `https://16ballcreations.com/$1` |
| IDX-10 | OK | Certificado válido (Cloudflare). Ningún `src` ni `href` usa `http://`. Search Console › HTTPS: 14 páginas por HTTPS y 0 sin HTTPS | — |
| IDX-11 | OK | `/servicios/video-para-redes/` hace un 301 a `/servicios/` y `/en/services/social-video/` un 301 a `/en/services/`, cada uno en un salto. `page.16ballcreations.workers.dev` hace un 301 por ruta al dominio y `/index.html` un 301 a `/` | Ojo: Google todavía muestra `page.16ballcreations.workers.dev` en los resultados de la marca, con la descripción vieja («ingeniero de software…»). Se irá con el tiempo; si sigue en noviembre, pedir su retiro desde una propiedad de Search Console de ese host |
| IDX-12 | OK | `/no-existe-xyz` y `/contacto/` responden 404 | — |
| IDX-13 | PARCIAL | Las URLs sin barra final hacen un **307 Temporary Redirect**: `/servicios` va a `/servicios/` y `/en/services` va a `/en/services/` | Que sean 301 o 308 (es una opción del hosting o una regla de Cloudflare) |
| IDX-14 | PARCIAL | Pendiente: no se encontró el archivo de clave y no hubo acceso a Bing para ver envíos | Activar «Crawler Hints» en Cloudflare, que avisa por IndexNow |
| IDX-15 | PARCIAL | Las 18 URLs tienen el mismo `lastmod`, `2026-10-22` | Que `lastmod` salga de la fecha real del último cambio de cada página |
| IDX-16 | OK | Las 18 páginas declaran `es`, `en` y `x-default` con URL absolutas que responden 200, y cada versión devuelve el enlace (por ejemplo, `/servicios/paginas-web/` y `/en/services/websites/`). Revisado el 20 nov sobre el commit `b28a773` | — |

### 3. Estructura y URLs (EST)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| EST-01 | OK | URLs con palabras y guiones (`/servicios/paginas-web/`, `/en/services/brand-audit/`) | — |
| EST-02 | OK | Sin barra final redirige (ver IDX-13), `/index.html` hace un 301 y `?utm_source=` da 200 con canonical a `/`. Las mayúsculas dan 404 | — |
| EST-03 | OK | Canonical absoluto y apuntando a sí misma en las 18 páginas; todos los destinos dan 200 sin `noindex`. El hreflang `es`/`en`/`x-default` es recíproco | — |
| EST-05 | OK | Todas las páginas de servicio están a 1 clic de la portada (sección Servicios) | — |
| EST-06 | OK | Cada URL del sitemap recibe enlaces internos: los servicios desde 9 páginas cada uno, y `/mira/` desde todas (con `?o=web`) | — |
| EST-07 | OK | Migas visibles («Inicio / Servicios / Páginas web») con `BreadcrumbList`. Search Console › Rutas de exploración: 12 válidas y 0 no válidas | — |

### 4. Intención y palabras clave (KW)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| KW-01 | FALLA | No hay en los documentos del proyecto una lista de búsquedas objetivo por página (se buscó en `Marketing/`) | Armar el mapa. Propuesta para que Renne la decida: portada, «estudio de marca Medellín»; `/servicios/paginas-web/`, «diseño de páginas web Medellín»; `/servicios/identidad-de-marca/`, «identidad de marca Medellín»; `/servicios/tiendas-en-linea/`, «tienda en línea con WhatsApp Medellín»; `/servicios/auditoria-de-marca/`, «auditoría de marca»; `/servicios/sistemas-para-tu-negocio/`, «sistema de inventario y pedidos para negocio pequeño»; `/mira/`, «16 Ball Creations MIRA» (de navegación) |
| KW-03 | FALLA | Como no hay lista, no hay intención clasificada | En el mismo documento: los servicios son transaccionales, la portada comercial y `/mira/` de navegación |
| KW-04 | OK | Para «diseño de páginas web Medellín», Google muestra un mapa con negocios locales y después páginas de servicio de agencias. `/servicios/paginas-web/` es una página de servicio, el tipo correcto | El tipo de página coincide; lo que falta es la zona en el título (LOC-04). Al mapa no se puede entrar sin perfil (LOC-00) |
| KW-05 | OK | Cada página de servicio tiene su propio tema. La portada apunta a «estudio de marca», no a la búsqueda de cada servicio. Con el método de la v0.3 (título y `<h1>`, sin artículos, preposiciones ni el nombre del negocio), ningún par de páginas del mismo idioma comparte el 40 % de las palabras; el más alto es `/en/services/` con `/en/services/online-stores/`, con 25 % | — |
| KW-07 | OK | Search Console (13-21 oct) no muestra consultas porque hay muy pocas y Google las anonimiza. Por página, en posición 5 a 20: `/en/services/` (5,3), `/en/services/online-stores/` (7,0), `/servicios/` (8,7), `/servicios/tiendas-en-linea/` (5,0), `/servicios/paginas-web/` (6,0), `/mira/` (7,0) | Volver a mirar en 4 semanas, cuando haya consultas visibles |
| KW-08 | OK | El texto se lee natural y ninguna página tiene `meta keywords` | — |
| KW-09 | OK | Los 9 títulos en español apuntan a lo que vende: marca, páginas web, tiendas, auditoría, asesoría de imagen y sistemas. «Sistemas para administrar tu negocio» es el más lejano a «estudio de marca», pero es un servicio que se vende. Criterio `H` | Que Renne confirme que sistemas sigue en la oferta pública |

### 5. Contenido (CON)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| CON-01 | OK | Cada página de servicio explica para quién es, qué incluye, el paso a paso, los casos («Lo hemos hecho») y las preguntas frecuentes, con un método propio (MIRA). Criterio `H`: esto es lo que propone el agente | Que Renne lo confirme. Lo más flojo es `/servicios/sistemas-para-tu-negocio/` (ver IDX-02) |
| CON-02 | OK | Párrafos cortos, encabezados y sin errores de ortografía a la vista | — |
| CON-03 | OK | Se buscaron entre comillas dos frases exactas (de páginas web y de identidad) y solo aparece 16ballcreations.com. Los casos y las capturas de proyectos son propios | — |
| CON-04 | OK | Sección «Quién está detrás / Quiénes somos» con Renne Castellanos como fundador, y `author` en la meta | — |
| CON-05 | OK | Portada: correo, WhatsApp, Instagram y formulario de la MIRA. Páginas de servicio: correo («Escríbenos»), Instagram y la MIRA | — |
| CON-06 | OK | No hay cifras externas; las cifras («13 años», «10+ proyectos», «3 países») son del propio negocio | — |
| CON-07 | OK | No hay precios ni ofertas vencidas en el sitio; «video para redes» ya se quitó y redirige | Los fragmentos de Google todavía nombran «video para redes» porque Google no ha vuelto a rastrear desde el 15-16 oct. Se corrige sola con el próximo rastreo |
| CON-08 | OK | En móvil (375 px) no aparece ninguna ventana emergente ni diálogo al entrar | — |
| CON-11 | OK | Ninguna página de servicio repite a otra con otro nombre. Comparten un marco de plantilla (el bloque de la MIRA, el «siempre en el mismo orden», la respuesta sobre precios y las tarjetas de casos): entre el 21 % (auditoría) y el 50 % (identidad) de sus palabras. El resto es propio de cada servicio | Vigilar identidad y asesoría, que están en la mitad: si crece la plantilla, que crezca también lo propio |
| CON-12 | OK | La portada, `/servicios/` y las 6 páginas de servicio cierran con «Haz tu MIRA gratis», y las de servicio tienen además «Escríbenos» | — |

### 6. Títulos, descripciones y encabezados (ONP)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| ONP-01 | OK | Los 18 títulos son únicos, ninguno es genérico y cada página tiene un solo `<title>` | — |
| ONP-02 | PARCIAL | La portada sí trae tema, ciudad y marca: «Estudio de marca y páginas web desde Medellín · 16 Ball Creations». Las páginas de servicio no dicen la ciudad («Diseño de páginas web · 16 Ball Creations»). Y «MIRA · 16 Ball Creations» no dice qué es | Servicios: «Diseño de páginas web en Medellín · 16 Ball Creations». MIRA: «MIRA: diagnóstico de marca gratis · 16 Ball Creations» |
| ONP-03 | OK | Ningún título repite palabras sin necesidad | — |
| ONP-04 | PARCIAL | La portada tiene 65 caracteres y `/en/services/` 77. Lo clave queda al principio, pero pasan de ~60 | Recortar el de `/en/services/` («Services: brand, websites and stores · 16 Ball Creations») |
| ONP-05 | PARCIAL | `/servicios/`: el `<h1>` es «Lo que hacemos, en orden» y el título «Servicios: marca, páginas web, tiendas y redes». `/mira/`: el `<h1>` es «Antes de ofrecerte nada, queremos mirarte» y el título «MIRA». En la portada y las páginas de servicio sí coinciden | Que esos dos `<h1>` nombren el tema, por ejemplo «Servicios de marca y páginas web, en orden» |
| ONP-06 | OK | Las 18 páginas tienen meta descripción propia y ninguna se repite | — |
| ONP-07 | PARCIAL | Entre 149 y 226 caracteres. La de la portada tiene 205, la de `/servicios/` 226 y la de sistemas 224 | Dejarlas en ~155 y quitar el cierre repetido «Empieza con tu MIRA gratis» donde sobre |
| ONP-08 | PARCIAL | En `/servicios/` el `<h1>` salta a seis `<h3>` sin un `<h2>` en medio. En las demás páginas el orden es correcto | Poner un `<h2>` («Servicios») o convertir esos `<h3>` en `<h2>` |
| ONP-10 | OK | `og:title`, `og:description` y `og:image` en todas las páginas; la imagen `og-16ballcreations.jpg` carga (200, 72 KB, 1200×630) | — |
| ONP-11 | OK | `favicon.ico` de 48 × 48 px y un PNG de 192 × 192 declarados en todas las páginas (MIRA usa `assets/img/favicon.png`) | — |
| ONP-12 | OK | `lang="es"` en las 9 páginas en español y `lang="en"` en las 9 en inglés | — |

### 7. Imágenes y video (IMG)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| IMG-02 | OK | Las imágenes de proyectos tienen `alt` descriptivo (por ejemplo, «Portada del sitio de KaffeePlatz: una AeroPress sobre fondo crema…»). La bola decorativa lleva `alt=""` | — |
| IMG-03 | OK | Nombres descriptivos: `psicoformando.jpg`, `kaffeeplatz.jpg`, `modularity-dashboard.jpg` | — |
| IMG-04 | OK | Lighthouse estima un ahorro total de 170 KiB, pero ninguna imagen pasa de 100 KB: la mayor es `psicoformando.jpg`, con 80 KiB de ahorro. Se sirven a 1200×747 y se muestran a 609×381 | Mejora sin urgencia: WebP y `srcset` a 600-800 px |
| IMG-05 | OK | Todas las imágenes tienen `width` y `height`. CLS 0 | — |
| IMG-06 | OK | Las imágenes de proyectos y de Modularity llevan `loading="lazy"` y la parte de arriba no tiene imágenes | — |

### 8. Enlaces (LNK)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| LNK-01 | OK | No hay enlaces con «aquí», «ver más» ni «clic aquí», ni enlaces vacíos sin `aria-label` | — |
| LNK-02 | OK | Los servicios reciben enlaces desde el contenido de la portada (sección Servicios) y desde `/servicios/`, no solo desde el menú | — |
| LNK-03 | OK | Los 19 enlaces internos dan 200. Los 9 externos (Instagram, GitHub, wa.me, psicoformando.com, kaffeeplatz.co, rivasseven.com, YouTube y el demo de Modularity) también | — |
| LNK-05 | N/A | No hay comentarios, foros ni enlaces pagados | — |
| LNK-06 | OK | Search Console › Enlaces: 0 enlaces externos, así que no hay ninguno comprado. Criterio `H` | Que Renne confirme que no hay intercambios |
| LNK-07 | OK | Ningún enlace interno de las 18 páginas apunta a una URL sin `/` final, a `index.html` ni a las retiradas (`/servicios/video-para-redes/`). Ojo: en la copia del 15 oct en web.archive.org, MIRA todavía enlazaba a `../index.html`; el 23 oct ya no | — |

### 9. Rendimiento y móvil (RND)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| RND-01 | FALLA | No hay datos de campo. En laboratorio (PageSpeed, móvil, 23 oct): **portada 3,7 s y `/servicios/paginas-web/` 3,3 s**. En la portada, el elemento LCP es el texto `p#heroKicker` y **3.510 ms son «retraso de renderizado»**: la animación de entrada lo muestra tarde. El servidor responde rápido | Mostrar el titular sin esperar la animación (o animar solo `transform`, con el texto ya visible). En servicios, revisar el retraso de la entrada del `<h1>` y los recursos que bloquean (150 ms) |
| RND-02 | OK | No hay INP de campo. En laboratorio, TBT de 80 ms en la portada y 0 ms en páginas web, como sustituto | Confirmar con datos de campo cuando haya tráfico |
| RND-03 | OK | CLS 0 en las dos páginas medidas | — |
| RND-04 | OK | Se aclara la fuente: PageSpeed no tiene datos de campo y Search Console › Core Web Vitals dice «Sin datos» en móvil y en ordenador, porque el sitio tiene poco tráfico. Todo lo de esta sección es de laboratorio | — |
| RND-05 | OK | Las 18 páginas tienen `viewport`. A 375 px no hay desplazamiento horizontal (`scrollWidth` 375), el texto principal se lee y los botones se pueden tocar. Las etiquetas pequeñas de los proyectos van a 11 px, pero no son texto principal | — |
| RND-06 | N/A | El LCP es texto, no una imagen, así que `fetchpriority` no aplica. El arreglo está en RND-01 | — |
| RND-07 | PARCIAL | En la portada: 2,5 s de trabajo en el hilo principal, 5 tareas largas, «Legacy JavaScript» de 10 KiB y JS sin minificar (7 KiB). No hay scripts de terceros | Minificar los JS y revisar `orb.js` y `table.js`, que son la animación |
| RND-09 | OK | TTFB de 0,23 a 0,28 s desde aquí (Cloudflare, con caché `HIT`) | — |

### 10. Datos estructurados (SCH)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| SCH-01 | OK | `ProfessionalService` con nombre, logo, URL, teléfono, correo, `contactPoint` y `sameAs` (Instagram y GitHub) | Agregar Facebook a `sameAs`, y los perfiles de directorios cuando existan |
| SCH-02 | PARCIAL | Tiene `areaServed` (Medellín, Antioquia, Colombia, Venezuela y Costa Rica) y teléfono, pero **falta el horario** (`openingHoursSpecification`) | Agregar el horario de atención, el mismo que se publique en directorios y redes |
| SCH-04 | PARCIAL | Casi todo lo marcado se ve en la página: teléfono, correo, 2013, el fundador, Modularity, el precio de la auditoría y Venezuela y Costa Rica en la portada. **«Antioquia» está en `areaServed` pero en ninguna página.** En las páginas de servicio, Venezuela y Costa Rica están marcados pero solo se ven en la portada | Escribir la zona en el texto de cada página («Medellín y el resto de Antioquia, y por videollamada en Colombia, Venezuela y Costa Rica») o quitar del marcado lo que no se diga |
| SCH-05 | OK | validator.schema.org (portada): 0 errores y 0 advertencias en WebSite (con `ProfessionalService`), SoftwareApplication y FAQPage. Search Console: rutas de exploración con 12 válidas y 0 no válidas | La Prueba de resultados enriquecidos no se corrió aparte; el validador y Search Console bastan |
| SCH-06 | PARCIAL | El JSON-LD y la página coinciden en nombre, teléfono y correo. No hay perfil de Google con qué comparar (no aplica, ver LOC-00), y **Facebook usa `16ballcreations@gmail.com`** y otra descripción (ver IA-05) | Igualar Facebook. Al abrir directorios, usar los mismos datos del JSON-LD |
| SCH-07 | OK | Hay `FAQPage` en la portada y en los servicios, y el sitio no lo vende como resultado enriquecido | — |

### 11. Búsqueda con IA (IA)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| IA-01 | PARCIAL | La portada cumple: su `<h1>` dice qué es, dónde y por qué elegirlo («estudio de marca en Medellín: hacemos que tu negocio cuente una sola historia…»). El primer párrafo de las 6 páginas de servicio dice qué es, pero no dónde ni quién, así que quedan a medias. Por ejemplo, «Un sitio hecho a la medida de tu marca, que se ve bien en el celular y hace fácil que te escriban» | Primera oración con qué, quién y dónde: «16 Ball Creations diseña páginas web a la medida para negocios pequeños en Medellín…» |
| IA-02 | OK | Los párrafos se entienden solos (las preguntas frecuentes sobre todo) | — |
| IA-03 | PARCIAL | En la portada, las tarjetas de proyectos (KaffeePlatz y los demás) **solo existen después del JavaScript** (`projects.js`): en `curl` no están. En las páginas de servicio, los casos sí están en el HTML | Generar las tarjetas de proyectos en el HTML del servidor |
| IA-04 | OK | `robots.txt` no bloquea `OAI-SearchBot`, `GPTBot`, `Google-Extended`, `Googlebot` ni `Bingbot` | — |
| IA-05 | PARCIAL | Mismo nombre en todas partes, pero el servicio cambia según el canal. Sitio: «estudio de marca y páginas web». Instagram: «16 Ball Creations ¦ Web × SEO × AEO». **Facebook: «proyecto orientado a múltiples áreas de desarrollo creativo… diseño gráfico… software», categoría «Internet company» y correo `16ballcreations@gmail.com`.** Según la prueba del 22 oct, LinkedIn y Torre dicen «productos web y móviles». En Google, por el nombre, todavía sale `page.16ballcreations.workers.dev` con la versión vieja | Igualar Facebook (descripción, categoría, `crea@` y el enlace al sitio), LinkedIn y Torre (4.7 del plan) y la descripción de Instagram |
| IA-07 | OK | Hay una prueba registrada el **22 oct 2026** en ChatGPT, Gemini y Copilot, con 5 preguntas, respuestas y fuentes (ver Prueba de IA). Hoy no se repitió | Repetirla a finales de noviembre, después de AUT-03 y LOC-03 |
| IA-08 | OK | `/llms.txt` existe y coincide con el sitio (servicios, precio de la auditoría, contacto, proyectos) | — |
| IA-09 | OK | Siempre dice «16 Ball Creations» (el `llms.txt` pide no abreviarlo) y los servicios se llaman igual en el menú, la portada y sus páginas | — |
| IA-10 | PARCIAL | Las páginas de servicio dicen qué y dónde (Medellín de 1 a 3 veces) y la auditoría tiene precio, pero **no tienen teléfono ni WhatsApp escritos**: solo el enlace de correo y la MIRA. Páginas web, identidad, tiendas y asesoría no dan un precio claro en el texto | Poner en cada servicio un bloque fijo: «Desde $X COP · Medellín y por videollamada · WhatsApp +57 310 494 9979 · crea@16ballcreations.com». Los precios los decide Renne |
| IA-11 | OK | La meta `robots` dice `index, follow, max-image-preview:large`, sin `noarchive`, `nocache` ni `nosnippet`, y no hay cabecera `X-Robots-Tag` | — |

### 12. SEO local (LOC)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| LOC-00 | Sin perfil posible | Trabaja en línea y por videollamada, sin local que atienda público. Google pidió una verificación en video de un negocio físico que no existe. Lo confirmó Renne el 23 oct | — |
| LOC-01 | N/A | Por el tipo de negocio, el perfil de empresa en Google no aplica. Buscando «16 Ball Creations» no aparece ningún perfil ni panel | Oportunidad, no falla: si algún día se puede verificar, crearlo como área de servicio (los datos están en [pendientes-seo-aeo.md](../../planes/pendientes-seo-aeo.md)) |
| LOC-02 | PARCIAL | El nombre y el teléfono coinciden en el sitio, el JSON-LD, Instagram y Facebook. **El correo de Facebook es otro** (`16ballcreations@gmail.com`) | Cambiar el correo en Facebook a `crea@16ballcreations.com`. En cada directorio nuevo, copiar exactamente lo del sitio |
| LOC-03 | FALLA | No hay reseñas en ninguna plataforma pública: Facebook dice «Not yet rated (0 reviews)» y no hay perfiles en directorios | Pedir reseñas a PsicoFormando, KaffeePlatz y Rivas Seven en Facebook y en Clutch o Sortlist (por `/testimonio/`), y responderlas todas |
| LOC-04 | FALLA | Ninguna página de servicio tiene la ciudad en el `<title>` ni en el `<h1>`. Solo la portada dice «Medellín» | `<title>`: «Diseño de páginas web en Medellín · 16 Ball Creations». `<h1>`: «Diseño de páginas web en Medellín, que cuentan quién eres». Lo mismo en identidad, tiendas y auditoría |
| LOC-05 | N/A | No hay páginas por ciudad | — |
| LOC-07 | N/A | No aplica al tipo «sin perfil posible» | — |
| LOC-08 | PARCIAL | La zona está escrita en el texto (Medellín de 1 a 3 veces por página de servicio) y en `areaServed` del JSON-LD, pero **no hay perfiles en directorios del sector** | Abrir perfiles en Clutch y Sortlist (ver AUT-03). Con eso, LOC-08 queda en `OK` |

### 13. Autoridad (AUT)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| AUT-01 | PARCIAL | Instagram enlaza a `16ballcreations.com/mira/?o=bio`. **Facebook no muestra el enlace al sitio** en la presentación. No hay página de empresa en LinkedIn (pendiente). WhatsApp Business no se pudo revisar | Agregar el sitio en Facebook y en el perfil de WhatsApp Business, y crear la página de LinkedIn |
| AUT-03 | FALLA | No está en Clutch, Sortlist ni ningún directorio (prueba del 22 oct). Hoy, «diseño de páginas web Medellín» muestra a Sortlist entre los primeros resultados | Abrir perfiles en Clutch y Sortlist con 2 o 3 reseñas de clientes reales (4.4 del plan) |
| AUT-04 | OK | Search Console › Enlaces: 0 enlaces externos. Internos: 3, dos hacia `/servicios/video-para-redes/` (dato viejo, de antes de la redirección) | Volver a revisar cuando existan los directorios |

### 14. Políticas de spam (SPAM)

| Código | Resultado | Evidencia | Corrección propuesta |
|---|---|---|---|
| SPAM-00 | OK | Search Console › Acciones manuales y › Problemas de seguridad: «No se ha detectado ningún problema» | — |
| SPAM-01 | OK | El HTML es idéntico (mismo MD5) con navegador normal, con agente `Googlebot` y con agente de celular. El JS cambia el texto de `#heroKicker`, pero lo hace igual para todos, y Googlebot lo ejecuta | — |
| SPAM-02 | OK | No hay clases `sr-only`/`hidden` con texto, `font-size:0`, `opacity:0` en línea ni posiciones fuera de pantalla | — |
| SPAM-03 | OK | Se lee natural y no hay bloques de barrios ni ciudades | — |
| SPAM-04 | OK | No hay páginas por ciudad ni variantes casi iguales. Las versiones `/en/` son traducciones con hreflang | — |
| SPAM-05 | OK | 0 enlaces externos y nada en el pie ni en *widgets* | — |
| SPAM-06 | OK | 18 páginas, cada una con contenido propio | — |
| SPAM-07 | OK | Las frases exactas solo aparecen en este sitio (ver CON-03) | — |
| SPAM-08 | OK | Escritorio y celular llegan a la misma URL y al mismo contenido | — |
| SPAM-09 | OK | Search Console no reporta problemas de seguridad y `site:` solo muestra páginas propias | — |
| SPAM-10 | OK | No hay comentarios, foros ni perfiles públicos | — |
| SPAM-11 | N/A | No hay enlaces de afiliado | — |
| SPAM-12 | OK | No hay secciones de terceros | — |
| SPAM-13 | OK | Dominio nuevo (activo desde el 14 oct 2026) y coherente con la marca, que existe desde 2013 | — |
| SPAM-14 | OK | Nombre, teléfono, correo y servicios reales y coherentes entre sí | — |
| SPAM-15 | OK | No hay instrucciones dirigidas a modelos ni en el HTML ni en `llms.txt`, que solo describe | — |
| SPAM-16 | OK | No hay reseñas marcadas. Los precios marcados ($0 de la MIRA y $700.000 de la auditoría) se ven en la página | — |

## Prueba de IA

No se repitió hoy. Se usa la del **22 oct 2026**, registrada en [mejoras-sitio-seo-aeo.md](../../planes/mejoras-sitio-seo-aeo.md) («La prueba de IA de 16 Ball: el antes»). ChatGPT la hizo el agente sin sesión; Gemini y Copilot los hizo Renne en chat temporal.

| Pregunta | ChatGPT | Gemini | Copilot |
|---|---|---|---|
| P3 · «¿Qué es 16 Ball Creations?» | No lo conoce | Lo conoce, con datos del sitio viejo (video, «ingeniero de software») | Lo conoce y cita solo el sitio; repite «video» y los tres países del `areaServed` |
| P1 · «¿Cuál es el mejor estudio de marca en Medellín?» | No lo nombra; cita Clutch | No lo nombra; cita Sortlist, Clutch y The Manifest | No lo nombra; muestra fichas de Bing Places y cita Sortlist |
| P5 · Barbería con dos nombres en Google e Instagram | No lo nombra; recomienda agencias con perfil de Google | No nombra a nadie | No nombra a nadie |

Fuentes que citan: Clutch, Sortlist, The Manifest, perfiles de Google y de Bing Places, LinkedIn, Torre y el portafolio en github.io. La conclusión coincide con esta auditoría: el sitio ya es la fuente de lo que la IA dice del negocio, pero para recomendarlo hacen falta directorios y reseñas (AUT-03 y LOC-03). Como 16 Ball no puede tener perfil de Google, los directorios pesan todavía más.

## Próximos pasos

1. [Importante] **KW-01 y KW-03** · Aprobar el mapa de búsquedas que se propone en KW-01. +6. *Renne.*
2. [Importante] **LOC-04 y ONP-02** · Poner «en Medellín» en el título y el `<h1>` de los servicios y darle a MIRA un título que diga qué es. +4,5. Sin perfil de Google, esta es la señal local más fuerte que queda. *Sitio.*
3. [Importante] **MED-03** · Analítica con tres conversiones: MIRA, WhatsApp y correo. +3. *Sitio.*
4. [Crítico] **LOC-02** · Cambiar en Facebook el correo a `crea@16ballcreations.com`. +2,5, y es lo más rápido de la lista. *Renne.*
5. [Crítico] **IDX-09** · Hacer que `http://www.` redirija en un solo 301 al dominio sin `www`. Es una regla de Cloudflare. *Sitio.*
6. [Crítico] **SCH-04** · Escribir «Antioquia», Venezuela y Costa Rica en el texto, o quitarlos del marcado de las páginas donde no se dicen. *Sitio.*
7. [Crítico] **IDX-03** · Que el titular y el `<h1>` de la portada se vean sin esperar la animación; con eso también baja el LCP (RND-01). *Sitio.*
8. [Crítico] **IDX-02** · Mejorar `/servicios/sistemas-para-tu-negocio/` (caso, para quién, rango de precio), enlazarla más y pedir la indexación. *Sitio + Renne.*
9. [Importante] **AUT-03, LOC-08 y LOC-03** · Perfiles en Clutch y Sortlist, y reseñas de clientes reales ahí y en Facebook. Reemplaza lo que el perfil de Google haría por un negocio con local. *Renne.*
10. [Importante] **RND-01** · LCP por debajo de 2,5 s en laboratorio. Sale casi todo del punto 7. *Sitio.*
11. [Importante] **IA-05, AUT-01 y SCH-06** · Igualar Facebook (descripción, categoría, enlace al sitio), LinkedIn y Torre con el sitio, y agregar Facebook a `sameAs`. *Renne + sitio.*
12. [Importante] **IA-01, IA-10 e IA-03** · Primera oración con qué, quién y dónde; un bloque de precio y contacto en cada servicio; proyectos de la portada en el HTML del servidor. *Sitio; los precios, Renne.*
13. [Importante] **SCH-02, ONP-05 y ONP-08** · Horario en el JSON-LD; `<h1>` de `/servicios/` y `/mira/` con el tema; `<h2>` en `/servicios/`. *Sitio.*
14. [Importante] **MED-02** · Confirmar o crear Bing Webmaster Tools (importando desde Search Console) y enviar el sitemap. *Renne.*
15. [Mejora] **IDX-07** (sitemap enviado sin `www`), **IDX-13** (307 → 301), **IDX-15** (`lastmod` real), **IDX-14** (Crawler Hints), **ONP-04 y ONP-07** (títulos y descripciones más cortos), **RND-07** (minificar JS). *Sitio.*

Los críticos van después de los tres primeros porque están en `PARCIAL`: cada uno suma 2,5, menos que los importantes que fallan del todo. Los pasos 4 y 5 son de minutos, así que conviene hacerlos de una vez aunque estén más abajo.

## Lo que no se pudo comprobar

| Punto | Motivo |
|---|---|
| MED-02 · Bing Webmaster Tools | Solo hubo acceso a Search Console. Sin Bing tampoco se pudo ver IndexNow (IDX-14) ni la indexación en Bing |
| PageSpeed por API | La API pública de PageSpeed respondió «Quota exceeded» el 23 oct a las 11:09. Se usó pagespeed.web.dev en el navegador: portada a las 11:15 y páginas web a las 11:17 |
| Lista de URLs indexadas de Search Console | El detalle de «Páginas» no cargó la lista de URLs en el navegador. Se usó la Inspección de URLs página por página (las 9 en español). Las 9 en inglés no se inspeccionaron una por una |
| Prueba de resultados enriquecidos | No se corrió aparte; se usaron validator.schema.org (portada) y el informe de Search Console |
| Datos de campo (CWV e INP) | El sitio todavía no tiene tráfico suficiente; Search Console y PageSpeed dicen «Sin datos» |
| WhatsApp Business (AUT-01) | El perfil de WhatsApp no se ve desde el navegador |
| Prueba de IA de hoy (IA-07) | No se repitió; se usó la del 22 oct |
| Puntos `H` | CON-01, LNK-06 y KW-09 los propone el agente y los confirma Renne |
| Puntos nuevos de la v0.3 | Se revisaron en el HTML del commit `b28a773`, no en el sitio publicado ese día. Es el mismo código, pero sin la respuesta del servidor (por ejemplo, el favicon y los enlaces se comprobaron como archivos y rutas, no con `curl`) |
