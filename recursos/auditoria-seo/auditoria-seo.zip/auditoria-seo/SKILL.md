---
name: auditoria-seo
description: Auditar el SEO y el AEO (búsqueda con IA) de un sitio web con el checklist de 16 Ball Creations (v0.3, 99 puntos en 14 áreas, más spam) y entregar el informe con puntuación de 0 a 100, nivel, insignias, evidencia por punto, correcciones ordenadas y próximos pasos. Úsalo siempre que pidan una auditoría SEO, revisar el posicionamiento de un sitio, «por qué no salgo en Google», validar si una página está bien hecha para buscadores o para ChatGPT/Gemini/Copilot, recalcular una auditoría con una versión nueva del checklist, o comparar un sitio antes y después de cambios, aunque no digan la palabra «auditoría». No es para la auditoría de marca (presencia en redes y prensa) ni para escribir textos.
---

# Auditoría SEO y AEO

Este skill convierte una URL en un informe que el dueño del negocio pueda leer y que quien tenga acceso al sitio pueda ejecutar. El número importa menos que lo que viene con él: qué está bien, qué frena al sitio y en qué orden arreglarlo.

## Archivos del skill

| Archivo | Cuándo leerlo |
|---|---|
| `references/checklist-seo-agente.md` | **Siempre, completo, antes de empezar.** Tiene las instrucciones, la puntuación, los 99 puntos con su forma de comprobar y el formato del informe. Es la regla. |
| `references/guia-seo.md` | Cuando un criterio del checklist no quede claro. Cada código del checklist corresponde a una sección de la guía, y si se contradicen, la guía manda. Secciones: 0 cómo leerla · 1 MED · 2 IDX · 3 EST · 4 KW · 5 CON · 6 ONP · 7 IMG · 8 LNK · 9 RND · 10 SCH · 11 IA (AEO) · 12 LOC · 13 AUT · 14 SPAM · 15 mitos · 16 qué se puede prometer · 17 referencias. |
| `references/ejemplo-auditoria-16bc.md` | Para ver un informe real terminado: tono, nivel de evidencia y cómo se escriben las correcciones. Es la auditoría de 16ballcreations.com (80/100). |
| `scripts/puntua.py` | Para calcular la puntuación cuando el informe tenga todos los resultados. No la calcules a mano. |

## Antes de empezar

1. **Pide o confirma la entrada:** la URL y qué accesos hay (Search Console, Bing Webmaster Tools, GA4). Sin acceso, esos puntos quedan `SIN ACCESO`, nunca `FALLA`: no se castiga lo que no se pudo ver.
2. **Clasifica el negocio (LOC-00):** con local, de área de servicio o sin perfil posible (trabaja en línea, o Google pidió una verificación que no puede hacer). Cambia cuánto vale el perfil de Google y qué puntos locales aplican. Si no está claro, pregunta: es la única decisión que mueve toda la puntuación.
3. **Solo lectura.** No cambies nada del sitio ni de las cuentas. En Search Console se pueden mirar informes y usar «Probar URL publicada», pero no se pide indexación ni se envían sitemaps. Las correcciones se proponen; las hace quien tenga permiso.

## Cómo trabajar

1. **Junta la evidencia primero.** `robots.txt`, `sitemap.xml`, `curl -sIL` de las variantes de dominio (`http`, `https`, con y sin `www`), `curl -s` de cada página a revisar (portada, contacto, todas las de servicio o producto y hasta 5 de contenido) y la página renderizada en el navegador. Guarda lo que encuentres con fecha y hora: el informe cita evidencia, no impresiones.
2. **Críticos primero.** Si `IDX-01` (el sitio está en Google) o `IDX-04` (`robots.txt` no bloquea) fallan, dilo de inmediato: lo demás no importa hasta que el sitio sea visible.
3. **Evalúa punto por punto, en el orden del checklist.** Cada resultado lleva evidencia concreta (URL, fragmento de HTML, cifra, captura). Los puntos que se revisan página por página siguen la regla «cumple / a medias / falla» de la sección Puntuación del checklist: solo la portada fuerza `FALLA` en un crítico, y con menos de tres páginas medidas decides por gravedad y lo explicas.
4. **Usa `REVISAR` cuando dudes** en un juicio de lectura (contenido, intención, títulos) o ante una sospecha de spam. No cuenta en la puntuación hasta que una persona decida. Los puntos con «Quién» = `H` los propones tú y los confirma una persona: dilo en el informe.
5. **Escribe el informe** con el formato del final del checklist, en un Markdown llamado `auditoria-seo-<negocio>-<AAAA-MM-DD>.md`.
6. **Puntúa con el script**, que lee el informe y aplica pesos, topes, niveles e insignias:
   ```bash
   python scripts/puntua.py <informe.md> --tipo {local,area,sin-perfil}
   ```
   Pega en el informe la cuenta, la tabla de áreas y las insignias que imprime. De su lista de arreglos, elige los tres que más suman: entre empates, gana el de menos esfuerzo y conviene agrupar arreglos que se hacen juntos (por ejemplo, la ciudad en título y `<h1>` resuelve LOC-04 y parte de ONP-02). Si el script dice que algún código no tiene resultado, complétalo antes de entregar.
7. **Cierra con «Lo que no se pudo comprobar»**: cada herramienta que no respondió, cuándo, y qué se usó en su lugar.

## Cómo escribir

- El lector es el dueño del negocio. Explica cada falla por lo que le pasa a su cliente o a Google, no por el nombre técnico. La evidencia puede ser técnica; la frase que la presenta, no.
- Las referencias de largo de títulos, cantidad de palabras u orden de encabezados son prácticas comunes, no reglas de Google. Nunca las presentes como requisitos, y una página corta no es una falla por sí sola.
- No prometas posiciones, tráfico ni ventas. La sección 16 de la guía dice qué se puede prometer.
- No inventes. Si algo no se pudo ver, se dice; si una herramienta falló, se anota cuál y cuándo.

## Lecciones de auditorías anteriores

- **PageSpeed:** la API pública a veces responde «Quota exceeded». Usa pagespeed.web.dev en el navegador y anota la hora de cada medición.
- **Search Console:** el detalle de «Páginas» a veces no carga la lista de URLs. La Inspección de URLs página por página sirve de respaldo.
- **Páginas que compiten (KW-05):** al comparar título y `<h1>`, quita artículos, preposiciones y el nombre del negocio, que va en todos los títulos y infla la coincidencia.
- **Perfiles fuera del sitio:** revisa Facebook, Instagram, LinkedIn y los directorios del sector. Ahí suelen estar el correo distinto, la descripción vieja o el enlace que falta (LOC-02, IA-05, AUT-01).

## Recalcular o comparar con una auditoría anterior

Si el checklist cambió de versión desde la auditoría anterior, recalcula la anterior con la versión nueva antes de mostrar la diferencia, o aclara que cambió el checklist. Para recalcular, evalúa los puntos nuevos sobre el sitio **tal como estaba el día de la auditoría**, no sobre el de hoy: el historial de git del sitio (el último commit antes de la hora de la revisión) o una copia de web.archive.org. Si la copia de Wayback llega ilegible, pídela con `Accept-Encoding: gzip`. Deja una nota de recálculo en el informe con qué cambió y por qué.
