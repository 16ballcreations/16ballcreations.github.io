"""Calcula la puntuación de una auditoría SEO con las reglas del checklist.

Uso:
    python puntua.py <informe.md> --tipo {local,area,sin-perfil} [--checklist <ruta>]

Lee los pesos del checklist (por defecto, references/checklist-seo-agente.md al lado
de esta carpeta) y los resultados del informe (filas «| CÓDIGO | RESULTADO | ...»).
Imprime la cuenta, el nivel con topes, la cobertura, las áreas (tabla lista para
pegar), las insignias, cuánto falta para el siguiente nivel y los arreglos que más suman.
"""
import argparse
import math
import os
import re
import sys

W = {'Crítico': 5, 'Importante': 3, 'Mejora': 1}
F = {'OK': 1.0, 'PARCIAL': 0.5, 'FALLA': 0.0}
RESULTADOS = ('OK', 'FALLA', 'PARCIAL', 'N/A', 'SIN ACCESO', 'REVISAR')
NIVELES = [(90, 'Referente'), (75, 'Por buen camino'), (60, 'En camino'), (40, 'Primeros pasos'), (0, 'Fuera del mapa')]
INSIGNIAS = [('Medido', ['MED']), ('Visible', ['IDX']), ('Ordenado', ['EST', 'LNK']), ('Claro', ['KW', 'ONP']),
             ('Útil', ['CON']), ('Bien ilustrado', ['IMG']), ('Rápido', ['RND']), ('Bien descrito', ['SCH']),
             ('Listo para la IA', ['IA']), ('Local', ['LOC']), ('Conocido', ['AUT'])]
ESFUERZO = {'minutos': 0, 'horas': 1, 'días': 2, 'dias': 2, 'semanas': 3}


def pesos(checklist, tipo):
    w, prio = {}, {}
    for l in open(checklist, encoding='utf-8'):
        m = re.match(r'^\| ([A-Z]{2,4}-\d\d) \|', l)
        if not m:
            continue
        code = m.group(1)
        if code.startswith('SPAM') or code == 'LOC-00' or code in w:
            continue
        cells = [c.strip() for c in l.split('|')]
        if len(cells) > 3 and cells[-3] in W:
            w[code] = W[cells[-3]]
            prio[code] = cells[-3]
    # LOC-01, LOC-07 y LOC-08 dependen del tipo de negocio (LOC-00)
    na = set()
    if tipo == 'local':
        w['LOC-01'], prio['LOC-01'] = 5, 'Crítico'
        na |= {'LOC-07', 'LOC-08'}
    elif tipo == 'area':
        w['LOC-01'], prio['LOC-01'] = 3, 'Importante'
        na |= {'LOC-08'}
    else:
        na |= {'LOC-01', 'LOC-07'}
        w['LOC-08'], prio['LOC-08'] = 3, 'Importante'
    for c in na:
        w.pop(c, None)
        prio.pop(c, None)
    return w, prio


def resultados(informe):
    res, esf, spam = {}, {}, {}
    for l in open(informe, encoding='utf-8'):
        m = re.match(r'^\| ([A-Z]{2,4}-\d\d) \| (' + '|'.join(re.escape(r) for r in RESULTADOS) + r') \|', l)
        if not m:
            continue
        code, r = m.group(1), m.group(2)
        if code.startswith('SPAM'):
            spam[code] = r
            continue
        res[code] = r
        cells = [c.strip() for c in l.split('|')]
        for c in cells[5:7]:
            if c.lower() in ESFUERZO:
                esf[code] = c.lower()
    return res, esf, spam


def nivel(score):
    for lim, name in NIVELES:
        if score >= lim:
            return name


def cuenta(w, res, override=None):
    r = dict(res)
    if override:
        r.update(override)
    e = p = 0.0
    for c, peso in w.items():
        if r.get(c) in F:
            e += peso * F[r[c]]
            p += peso
    return e, p, r


def tope(w, prio, r, spam):
    if any(v == 'FALLA' for v in spam.values()):
        return 'riesgo'
    n = sum(1 for c in w if prio.get(c) == 'Crítico' and r.get(c) == 'FALLA')
    return 39 if n >= 2 else (59 if n == 1 else None)


def final(w, prio, res, spam, override=None):
    e, p, r = cuenta(w, res, override)
    bruto = round(100 * e / p) if p else 0
    t = tope(w, prio, r, spam)
    if t == 'riesgo':
        return e, p, bruto, bruto, 'En riesgo'
    s = min(bruto, t) if t else bruto
    return e, p, bruto, s, nivel(s)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser()
    ap.add_argument('informe')
    ap.add_argument('--tipo', required=True, choices=['local', 'area', 'sin-perfil'])
    ap.add_argument('--checklist', default=os.path.join(here, '..', 'references', 'checklist-seo-agente.md'))
    a = ap.parse_args()

    w, prio = pesos(a.checklist, a.tipo)
    res, esf, spam = resultados(a.informe)
    total_tipo = sum(w.values())

    faltan = [c for c in w if c not in res]
    revisar = [c for c, r in res.items() if r == 'REVISAR']
    e, p, bruto, s, niv = final(w, prio, res, spam)
    na_otros = sum(w[c] for c, r in res.items() if r == 'N/A' and c in w)
    sin_acceso = sum(w[c] for c, r in res.items() if r == 'SIN ACCESO' and c in w)
    cobertura = 100 * p / (total_tipo - na_otros) if total_tipo - na_otros else 0

    def fmt(x):
        return f'{x:.1f}'.rstrip('0').rstrip('.').replace('.', ',')

    print(f'Puntos ganados: {fmt(e)} de {fmt(p)} posibles '
          f'({total_tipo} del tipo, menos {na_otros} de otros N/A y {sin_acceso} de SIN ACCESO)')
    print(f'Puntuación: {s} / 100 · {niv}' + (f' (sin tope sería {bruto})' if s != bruto else '')
          + f' · cobertura {round(cobertura)} %' + (' · PROVISIONAL (cobertura < 70 %)' if cobertura < 70 else ''))
    if any(v == 'REVISAR' for v in spam.values()):
        print('Spam: hay puntos en REVISAR → el nivel va con la marca «pendiente de revisión»')
    if faltan:
        print('Sin resultado en el informe (revisar):', ', '.join(faltan))
    if revisar:
        print('En REVISAR (no cuentan hasta que decida una persona):', ', '.join(revisar))

    # Áreas
    areas = {}
    for c in w:
        areas.setdefault(c.split('-')[0], []).append(c)
    print('\n| Área | Puntuación |\n|---|---|')
    for ar, cs in areas.items():
        ea = sum(w[c] * F[res[c]] for c in cs if res.get(c) in F)
        pa = sum(w[c] for c in cs if res.get(c) in F)
        if not pa:
            print(f'| {ar} | sin puntos evaluados |')
            continue
        pct = round(100 * ea / pa)
        n = round(pct / 10)
        print(f'| {ar} | {"█" * n}{"░" * (10 - n)} {pct} % |')

    # Insignias
    gan, cerca = [], []
    for name, ars in INSIGNIAS:
        cs = [c for c in w if c.split('-')[0] in ars and prio[c] in ('Crítico', 'Importante')]
        pend = [c for c in cs if res.get(c) not in ('OK', 'N/A')]
        if cs and not pend:
            gan.append(name)
        elif cs:
            cerca.append((sum(w[c] * (1 - F.get(res.get(c), 0)) for c in pend), name, pend))
    if spam and all(v in ('OK', 'N/A') for v in spam.values()) and spam.get('SPAM-00') == 'OK':
        gan.append('Juego limpio')
    print('\nInsignias:', ' · '.join(gan) if gan else 'ninguna')
    if cerca:
        cerca.sort()
        print(f'Insignia más cerca: {cerca[0][1]} (falta {", ".join(cerca[0][2])})')

    # Siguiente nivel
    if niv != 'En riesgo':
        sig = next(((lim, nm) for lim, nm in reversed(NIVELES) if lim > s), None)
        if sig:
            print(f'Te faltan {sig[0] - s} puntos para «{sig[1]}» ({sig[0]}).')

    # Arreglos que más suman (cada uno por separado, con topes)
    cands = []
    for c, r in res.items():
        if c in w and r in ('FALLA', 'PARCIAL'):
            _, _, _, s2, _ = final(w, prio, res, spam, {c: 'OK'})
            quita_tope = prio[c] == 'Crítico' and r == 'FALLA'
            cands.append((-int(quita_tope), -w[c] * (1 - F[r]), ESFUERZO.get(esf.get(c), 9), c, s2 - s, r))
    cands.sort()
    print('\nArreglos ordenados (quita tope, peso ganado, esfuerzo):')
    for qt, g, ef, c, ds, r in cands[:10]:
        sube = f'+{ds} (quita el tope)' if qt else f'+{fmt(-100 * g / p)}'
        print(f'  [{prio[c]}] {c} ({r}) · +{fmt(-g)} de peso · {sube} en la puntuación'
              + (f' · {esf[c]}' if c in esf else ''))
    rapidos = [c for _, _, ef, c, _, _ in cands if ef <= 1 and prio[c] in ('Crítico', 'Importante')]
    if rapidos:
        print('Arreglos rápidos (minutos u horas):', ', '.join(rapidos))
    top3 = [c for *_, c, _, _ in cands[:3]]
    if top3:
        override = {c: 'OK' for c in top3}
        print(f'Con los tres primeros, el sitio sube a {final(w, prio, res, spam, override)[3]}.')


if __name__ == '__main__':
    sys.exit(main())
